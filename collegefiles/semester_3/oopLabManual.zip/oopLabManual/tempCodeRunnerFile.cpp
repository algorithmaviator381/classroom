h (float denominator)
    // {
    //     cout<<"Cannot divide by zero" << endl;
    // }